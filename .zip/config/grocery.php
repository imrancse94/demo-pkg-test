<?php

return [

    'GOOGLE_RECAPTCHA_SECRET'=>env('GOOGLE_RECAPTCHA_SECRET'),
    'ADMIN_EMAIL'=>env('ADMIN_EMAIL'),
    'default_pagination'=>10,
];
