import axiosInstance from "./utils/axios.js";

window.axios = axiosInstance;
